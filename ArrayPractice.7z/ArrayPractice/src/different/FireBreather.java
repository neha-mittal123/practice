package different;

public interface FireBreather extends Animal { }
