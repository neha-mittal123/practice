package arrayPractice;

public class ThreadExample {

}
