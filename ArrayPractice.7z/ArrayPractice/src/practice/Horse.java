package practice;

public class Horse {
	public String identifyMyself() {
        return "I am a horse.";
    }
}
