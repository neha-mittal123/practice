package com.factoryDesignPattern;

public class SMSNotificationImpl implements Notification {

	@Override
	public void notifyUser() {
		System.out.println("sms notification");
		
	}

}
