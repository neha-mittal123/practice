package com.factoryDesignPattern;

public interface Notification {

	void notifyUser();
}
