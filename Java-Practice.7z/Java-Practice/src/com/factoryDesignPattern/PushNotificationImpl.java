package com.factoryDesignPattern;

public class PushNotificationImpl implements Notification{

	@Override
	public void notifyUser() {
		System.out.println("Push Notification");
	}

}
