package GooglePractice;

public class StrModel {
    int index;
    int negativeDepth;
    int balance;
}
